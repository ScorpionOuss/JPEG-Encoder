#include <stdlib.h>
#include <stdio.h>

int main(void)
{
    printf("Au boulot!\n");

    return EXIT_SUCCESS;
}